/* User-Defined Memory (UDM) Macros
 UMDI(0) sourceEn                 **the latent heat release**
 UMDI(1) log10(eta1)              **the logarithm of the relative viscosity depending on the volume fraction of crystals**
 UDMI(2) mu                       **the lava viscosity**
 UDMI(3) log10(MU0)               **the logarithm of the melt viscosity**
 UDMI(4) C_VOF(c,t)               **to store the function alpha (in Eq. 6, see Zeinalova et al., 2024; https://doi.org/10.1093/gji/ggad415)** 
 UDMI(5) source                   **the radiative and nonlinear convective heat transfer HT** 
 UDMI(6) C_UDMI(c,t,8)*C_VOF(c,t) **to capture the values of the volume fraction of crystals at the equilibrium state \phi_eq for phase 2 (lava)*
 UDMI(7) C_UDSI(c,t,0)*C_VOF(c,t) **to capture the values of the volume fraction of crystals for phase 2 (lava)** 
 UDMI(8) phi_eq                   **the temperature-dependent volume fraction of crystals at the equilibrium state \phi_eq**
 UDSI(0) phi                      **the user-defined scalar (UDS) transport equation describing the simplified crystal growth kinetics** 
*/

#include "udf.h"
#include "math.h"

#define  phi_m 0.591     /*the specific volume fraction of crystals (in Eq. 9; see Zeinalova et al., 2024; https://doi.org/10.1093/gji/ggad415)*/

#define  delta 7.24     /*the rheological parameter \delta (in Eq. 9)*/

#define  gamma_m 5.76   /*the rheological parameter \gamma (in Eq. 9)*/

#define  xi_m 4.63e-4   /*the rheological parameter \ksi (in Eq. 9)*/

#define L_star 3.5e5    /*the latent heat coefficient*/
#define B 2.5           /*the Einstein coefficient (in Eq. 9)*/

#define pi 3.141592



#define tau1_ (24*5.0*3600)  /*the characteristic time of the crystal content growth in seconds */

int global_iter = 0;

double erf(real x)      /*the error function in Eq. 9*/
{
    /* constants */
    real a1 =  0.254829592;
    real a2 = -0.284496736;
    real a3 =  1.421413741;
    real a4 = -1.453152027;
    real a5 =  1.061405429;
    real p  =  0.3275911;
    real t, y;

    /* Save the sign of x */
    int sign = 1;
    if (x < 0)
        sign = -1;
    x = fabs(x);

    
    t = 1.0/(1.0 + p*x);
    y = 1.0 - (((((a5*t + a4)*t) + a3)*t + a2)*t + a1)*t*exp(-x*x);

    return sign*y;
}

real getRelaxTime1(void)    /* returns the characteristic time of the crystal content growth */
{
return tau1_;
}


/**************************************************************/
/* the user-defined function to specify the lava viscosity*/
/**************************************************************/


DEFINE_PROPERTY(mvp11,c,t)    /* the function to return the viscosity for lava */
{
real T = C_T(c,t);             /*the value of the temperature from the energy equation*/ 
real phi_eq,a1;
if(T<280) T = 300;       /*the function to define the temperature dependent phi_eq (Moore & Carmichael, 1998)*/   
a1 = -42.4 + 51.04*(T-273)/1000 -11.11*pow(((T-273)/1000),2);
phi_eq = 1/(1+exp(a1));
C_UDMI(c,t,8)= phi_eq;    /*to store the value of phi_eq*/
return C_UDMI(c,t,2);   /*computed in part DEFINE_EXECUTE_AT_END*/
}

/**************************************************************/


/**************************************************************/
/* the user-defined scalar transport equation to describe
 the simplified crystal growth kinetics*/
/**************************************************************/


DEFINE_SOURCE(sourcePHI, c, t, dS, eqn)
{
real source;
real tau = getRelaxTime1();    
source = -C_VOF(c,t)*C_R(c,t)*(C_UDSI(c,t,0)-C_UDMI(c,t,8))/tau;    /*the source term - the right part of Eq. 10 (see Zeinalova et al., 2024; https://doi.org/10.1093/gji/ggad415)*/ 
dS[eqn] = - C_VOF(c,t)*C_R(c,t)/tau;    /*the derivative of the source term*/

return source;
}

/**************************************************************/


/**************************************************************/
/*the user-defined source term in the energy equation 
to describe the latent heat release due to crystalization*/ 
/**************************************************************/


DEFINE_SOURCE(sourceEn, c, t, dS, eqn)
{
real source;
real ro = 2500; /*the density of the lava */
source = -ro*L_star*(C_UDMI(c,t,7)-C_UDMI(c,t,6))/tau1_;    /*the source term - the right part of the latent heat term*/
dS[eqn] = 0;    /*the derivative of the source term*/

C_UDMI(c,t,0) = source;     /*to store the value of the source term*/
return source;
}

/**************************************************************/

/**************************************************************/
/* the user-defined source term in energy equation to decribe
 the radiative and nonlinear convective heat transfer (HF_n) at the lava-air interface  */
/**************************************************************/

DEFINE_SOURCE(source_nonlinear, c, t, dS, eqn)
{
real T = C_T(c,t);    /*the temperature from the energy equation*/
real Ta = 300;        /*the air temperature*/
real V= C_VOLUME(c,t);  /*the cell volume*/
real source;
real eps = 0.9;   /*the effective emissivity */
real lambda = 5.5;    /*the nonlinear convective heat transfer coefficient*/
real sigma = 5.6e-8;  /* Stefan–Boltzmann constant */

real S = 0.8;   /* the edge size of the cell*/

/*introducing the HF_n at the lava-air interface in Eq. 3 (see Zeinalova et al., 2024; https://doi.org/10.1093/gji/ggad415) */
if (T<Ta) T = Ta;

/*defining the interface between the lava and air, where we introduce the HF_n*/  
if ((C_UDMI(c,t,4)>0.001)&&(C_UDMI(c,t,4)<0.3)) {
source = -(eps*sigma*(pow(T,4.0)-pow(Ta,4.0)) + lambda*pow(T-Ta,4.0/3.0))*S/V;  /* the source term  - Nonlinear HF_n*/
dS[eqn] = -(4.0*eps*sigma*pow(T,3.0) + lambda*4.0/3.0*pow(T-Ta,1.0/3.0))*S/V;   /*the derivative of the source term*/
}
else 
{
source = 0;
dS[eqn] = 0;
}
C_UDMI(c,t,5) = source;   /*to store the value of the source term*/
return source;
}

/**************************************************************/

/**************************************************************/
/* to define a macro that is executed at the end of a time step*/
/**************************************************************/

DEFINE_EXECUTE_AT_END(vof_store) 
{
Domain *domain; 
Thread *t;
cell_t c;
real time_days = CURRENT_TIME/(3600.0*24);  /* to store the running time in days*/

real mu, MU0;
real A, F, eta1,c1;

/*to print modeling current time in days*/ 

#if !RP_NODE /* SERIAL or HOST */
  Message("Current time is %f days\n", time_days);
#endif /* !RP_NODE */



/* Get region for phase 2*/
domain = Get_Domain(3);
/* to store the function alpha (in Eq. 6, see Zeinalova et al., 2024; https://doi.org/10.1093/gji/ggad415)*/
thread_loop_c (t,domain)
 {
   begin_c_loop (c,t)
      {
       C_UDMI(c,t,4) = C_VOF(c,t);
      }
   end_c_loop (c,t)
 }
thread_loop_c (t,domain)
 {
   begin_c_loop (c,t)
      {
       C_UDMI(c,t,6) = C_UDMI(c,t,8)*C_VOF(c,t);  /*to capture values of the volume fraction of crystals at the equilibrium state (phi_eq) for phase 2 (lava)*/ 
       C_UDMI(c,t,7) = C_UDSI(c,t,0)*C_VOF(c,t);  /*to capture values of the volume fraction of crystals for phase 2 (lava)*/
      }
   end_c_loop (c,t)
 }
/*to calculate the lava viscosity at the end of a time step */
/*domain = Get_Domain(1);*/
thread_loop_c (t,domain)
 {
   begin_c_loop (c,t)
      {
    /*To calculate the lava viscosity in equation Eq. 9 (see Zeinalova et al., 2024; https://doi.org/10.1093/gji/ggad415)*/
      real T = C_T(c,t);
      real phi = C_UDSI(c,t,0); 
      real phi1 = MAX(phi/phi_m,0);
      A = phi1*(1+pow(phi1,gamma_m));
      F = 1-(1-xi_m)*erf(sqrt(pi)*A/(2.0*(1-xi_m)));
      eta1 = (1+pow(phi1,delta))*(pow(F,(-B*phi_m)));
        /*to calculate the melt viscosity by the Vogel–Fulcher–Tammann equation*/
      c1 = 13;
      if (T>984) c1 = MIN( (0.29 + 606.9/(T-273-710)), 13);

      MU0 = pow(10, c1);
     
      mu = eta1*MU0;    /*the lava viscosity as a multiplication of the melt viscosity and the viscosity depending on the crystals*/
      if (mu>1e13) mu = 1e13; /* to limit the magnitude of the lava viscosity*/
 
      C_UDMI(c,t,1) = log10(eta1);   /*to store the value of the logarithm of the viscosity depending on the crystals*/ 
      C_UDMI(c,t,2) = mu;            /*to store the value of the lava viscosity */
      C_UDMI(c,t,3) = log10(MU0);    /*to store the value of the logarithm of the melt viscosity*/   
      }
   end_c_loop (c,t)
 }
 /**************************************************************/
}


